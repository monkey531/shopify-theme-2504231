// Management Scripts
document.addEventListener('DOMContentLoaded', function() {
  // Initialize tooltips
  const tooltips = document.querySelectorAll('[data-tooltip]');
  tooltips.forEach(tooltip => {
    tooltip.addEventListener('mouseenter', showTooltip);
    tooltip.addEventListener('mouseleave', hideTooltip);
  });

  // Initialize search functionality
  const searchInput = document.querySelector('.management-search__input');
  if (searchInput) {
    searchInput.addEventListener('input', debounce(handleSearch, 300));
  }

  // Initialize filter buttons
  const filterButtons = document.querySelectorAll('.management-filter');
  filterButtons.forEach(button => {
    button.addEventListener('click', handleFilter);
  });

  // Initialize pagination
  const paginationButtons = document.querySelectorAll('.management-pagination__button');
  paginationButtons.forEach(button => {
    button.addEventListener('click', handlePagination);
  });

  // Initialize form validation
  const forms = document.querySelectorAll('.management-form');
  forms.forEach(form => {
    form.addEventListener('submit', handleFormSubmit);
  });

  // Initialize action buttons
  const actionButtons = document.querySelectorAll('.management-action-button');
  actionButtons.forEach(button => {
    button.addEventListener('click', handleAction);
  });

  // Initialize status badges
  const statusBadges = document.querySelectorAll('.management-status');
  statusBadges.forEach(badge => {
    animateStatusBadge(badge);
  });
});

// Tooltip functions
function showTooltip(event) {
  const tooltip = document.createElement('div');
  tooltip.className = 'management-tooltip';
  tooltip.textContent = this.dataset.tooltip;
  document.body.appendChild(tooltip);

  const rect = this.getBoundingClientRect();
  tooltip.style.top = `${rect.top - tooltip.offsetHeight - 10}px`;
  tooltip.style.left = `${rect.left + (rect.width - tooltip.offsetWidth) / 2}px`;

  tooltip.classList.add('show');
}

function hideTooltip() {
  const tooltip = document.querySelector('.management-tooltip');
  if (tooltip) {
    tooltip.classList.remove('show');
    setTimeout(() => tooltip.remove(), 300);
  }
}

// Search functionality
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

function handleSearch(event) {
  const searchTerm = event.target.value.toLowerCase();
  const items = document.querySelectorAll('.management-table tr, .management-card');
  
  items.forEach(item => {
    const text = item.textContent.toLowerCase();
    if (text.includes(searchTerm)) {
      item.style.display = '';
      item.style.animation = 'fadeIn 0.3s ease-out';
    } else {
      item.style.display = 'none';
    }
  });
}

// Filter functionality
function handleFilter(event) {
  const filter = event.target.dataset.filter;
  const items = document.querySelectorAll('.management-table tr, .management-card');
  
  // Update active state
  document.querySelectorAll('.management-filter').forEach(button => {
    button.classList.remove('management-filter--active');
  });
  event.target.classList.add('management-filter--active');
  
  items.forEach(item => {
    if (filter === 'all' || item.dataset.category === filter) {
      item.style.display = '';
      item.style.animation = 'fadeIn 0.3s ease-out';
    } else {
      item.style.display = 'none';
    }
  });
}

// Pagination functionality
function handlePagination(event) {
  event.preventDefault();
  const page = event.target.dataset.page;
  
  // Update active state
  document.querySelectorAll('.management-pagination__button').forEach(button => {
    button.classList.remove('management-pagination__button--active');
  });
  event.target.classList.add('management-pagination__button--active');
  
  // Load page content
  loadPageContent(page);
}

function loadPageContent(page) {
  const container = document.querySelector('.management-container');
  container.classList.add('management-loading');
  
  // Simulate loading
  setTimeout(() => {
    container.classList.remove('management-loading');
    // Add your actual page loading logic here
  }, 500);
}

// Form handling
function handleFormSubmit(event) {
  event.preventDefault();
  const form = event.target;
  const formData = new FormData(form);
  
  // Validate form
  if (validateForm(form)) {
    // Show loading state
    form.classList.add('management-loading');
    
    // Submit form
    submitForm(formData)
      .then(response => {
        showAlert('success', 'Form submitted successfully!');
        form.reset();
      })
      .catch(error => {
        showAlert('error', 'An error occurred. Please try again.');
      })
      .finally(() => {
        form.classList.remove('management-loading');
      });
  }
}

function validateForm(form) {
  let isValid = true;
  const inputs = form.querySelectorAll('input[required], textarea[required]');
  
  inputs.forEach(input => {
    if (!input.value.trim()) {
      isValid = false;
      input.classList.add('error');
      showAlert('error', `${input.name} is required`);
    } else {
      input.classList.remove('error');
    }
  });
  
  return isValid;
}

// Action button handling
function handleAction(event) {
  const action = event.target.dataset.action;
  const itemId = event.target.closest('tr, .management-card').dataset.id;
  
  if (action === 'delete') {
    if (confirm('Are you sure you want to delete this item?')) {
      deleteItem(itemId)
        .then(() => {
          showAlert('success', 'Item deleted successfully');
          event.target.closest('tr, .management-card').remove();
        })
        .catch(error => {
          showAlert('error', 'Failed to delete item');
        });
    }
  } else if (action === 'edit') {
    // Handle edit action
    window.location.href = `/admin/edit/${itemId}`;
  }
}

// Alert messages
function showAlert(type, message) {
  const alert = document.createElement('div');
  alert.className = `management-alert management-alert--${type}`;
  alert.textContent = message;
  
  document.querySelector('.management-container').prepend(alert);
  
  setTimeout(() => {
    alert.classList.add('hide');
    setTimeout(() => alert.remove(), 300);
  }, 3000);
}

// Status badge animation
function animateStatusBadge(badge) {
  const status = badge.dataset.status;
  const colors = {
    active: '#22C55E',
    inactive: '#EF4444',
    pending: '#F59E0B'
  };
  
  badge.style.backgroundColor = colors[status];
  badge.style.animation = 'pulse 2s infinite';
}

// Helper functions
async function submitForm(formData) {
  // Add your form submission logic here
  return new Promise((resolve) => setTimeout(resolve, 1000));
}

async function deleteItem(itemId) {
  // Add your delete logic here
  return new Promise((resolve) => setTimeout(resolve, 1000));
} 